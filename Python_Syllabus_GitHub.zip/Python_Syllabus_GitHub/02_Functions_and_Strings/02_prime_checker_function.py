"""Practical: 2.2 Prime Checker Function"""

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

roll_no = int(input("Enter your roll number: "))
for number in range(roll_no, roll_no + 11):
    if is_prime(number):
        print(number, "is prime")
