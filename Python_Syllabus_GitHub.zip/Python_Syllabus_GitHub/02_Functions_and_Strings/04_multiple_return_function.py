"""Practical: 2.4 Multiple-Return Function"""

def stats(a, b, c):
    return a + b + c, (a + b + c) / 3, min(a, b, c), max(a, b, c)

a = float(input("Enter first number: "))
b = float(input("Enter second number: "))
c = float(input("Enter third number: "))
total, average, minimum, maximum = stats(a, b, c)
print("Sum:", total)
print("Average:", average)
print("Minimum:", minimum)
print("Maximum:", maximum)
