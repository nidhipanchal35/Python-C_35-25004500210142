"""Practical: 2.3 Factorial Function"""

def factorial(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

print(f"{'Number':<10}{'Factorial':<15}")
print("-" * 25)
for number in range(1, 11):
    print(f"{number:<10}{factorial(number):<15}")
