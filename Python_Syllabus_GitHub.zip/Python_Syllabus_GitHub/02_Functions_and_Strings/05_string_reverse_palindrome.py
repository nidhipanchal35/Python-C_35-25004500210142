"""Practical: 2.5 String Reverse & Palindrome"""

def reverse_string(s):
    return s[::-1]

def is_palindrome(s):
    cleaned = s.lower().replace(" ", "")
    return cleaned == reverse_string(cleaned)

for text in ["madam", "racecar", "Nidhi", "Ahmedabad"]:
    print(f"{text!r} reversed = {reverse_string(text)!r}; palindrome = {is_palindrome(text)}")
