# Practical Index

| Practical | Topic | File |
|---|---|---|
| 1.1 | 1.1 Hello World & Introduction | `01_Python_Basics/01_hello_world.py` |
| 1.2 | 1.2 Formatted Introduction | `01_Python_Basics/02_formatted_introduction.py` |
| 1.3 | 1.3 Simple Interest Calculator | `01_Python_Basics/03_simple_interest.py` |
| 1.4 | 1.4 Temperature Converter | `01_Python_Basics/04_temperature_converter.py` |
| 1.5 | 1.5 Area & Perimeter | `01_Python_Basics/05_area_and_perimeter.py` |
| 1.6 | 1.6 Salary Calculator | `01_Python_Basics/06_salary_calculator.py` |
| 1.7 | 1.7 Digit Extractor | `01_Python_Basics/07_digit_extractor.py` |
| 1.8 | 1.8 Unit Converter | `01_Python_Basics/08_unit_converter.py` |
| 1.9 | 1.9 Swap Without Temporary Variable | `01_Python_Basics/09_swap_without_temp.py` |
| 1.10 | 1.10 BMI Calculator | `01_Python_Basics/10_bmi_calculator.py` |
| 1.11 | 1.11 Percentage Calculator | `01_Python_Basics/11_percentage_calculator.py` |
| 1.12 | 1.12 Electric Bill Calculator | `01_Python_Basics/12_electric_bill.py` |
| 1.13 | 1.13 Number Classifier | `01_Python_Basics/13_number_classifier.py` |
| 1.14 | 1.14 Grade Calculator | `01_Python_Basics/14_grade_calculator.py` |
| 1.15 | 1.15 Multiplication Table | `01_Python_Basics/15_multiplication_table.py` |
| 1.16 | 1.16 Factorial Finder | `01_Python_Basics/16_factorial_finder.py` |
| 1.17 | 1.17 Prime Number Checker & List | `01_Python_Basics/17_prime_checker_and_list.py` |
| 1.18 | 1.18 Fibonacci Series | `01_Python_Basics/18_fibonacci_series.py` |
| 1.19 | 1.19 Number Reversal & Palindrome | `01_Python_Basics/19_number_reversal_palindrome.py` |
| 1.20 | 1.20 Star Pattern Collection | `01_Python_Basics/20_star_patterns.py` |
| 1.21 | 1.21 Armstrong Number Finder | `01_Python_Basics/21_armstrong_number.py` |
| 1.22 | 1.22 ATM PIN Simulator | `01_Python_Basics/22_atm_pin_simulator.py` |
| 1.23 | 1.23 Sum of Series | `01_Python_Basics/23_sum_of_series.py` |
| 1.24 | 1.24 Number Pattern | `01_Python_Basics/24_number_patterns.py` |
| 2.1 | 2.1 Function Basics | `02_Functions_and_Strings/01_function_basics.py` |
| 2.2 | 2.2 Prime Checker Function | `02_Functions_and_Strings/02_prime_checker_function.py` |
| 2.3 | 2.3 Factorial Function | `02_Functions_and_Strings/03_factorial_function.py` |
| 2.4 | 2.4 Multiple-Return Function | `02_Functions_and_Strings/04_multiple_return_function.py` |
| 2.5 | 2.5 String Reverse & Palindrome | `02_Functions_and_Strings/05_string_reverse_palindrome.py` |
| 2.6 | 2.6 Vowel Counter & Character Frequency | `02_Functions_and_Strings/06_vowel_and_character_frequency.py` |
| 2.7 | 2.7 Modular Calculator | `02_Functions_and_Strings/07_modular_calculator.py` |
| 2.8 | 2.8 String Methods Practice | `02_Functions_and_Strings/08_string_methods.py` |
| 2.9 | 2.9 Anagram Checker | `02_Functions_and_Strings/09_anagram_checker.py` |
| 2.10 | 2.10 Report Card with f-strings | `02_Functions_and_Strings/10_report_card_fstrings.py` |
| 2.11 | 2.11 Default Parameter Function | `02_Functions_and_Strings/11_default_parameter_function.py` |
| 2.12 | 2.12 Lambda Sort | `02_Functions_and_Strings/12_lambda_sort.py` |
| 3.1 | 3.1 List Statistics | `03_Data_Structures/01_list_statistics.py` |
| 3.2 | 3.2 Stack Simulator | `03_Data_Structures/02_stack_simulator.py` |
| 3.3 | 3.3 List Comprehension Lab | `03_Data_Structures/03_list_comprehension_lab.py` |
| 3.4 | 3.4 Tuple Operations | `03_Data_Structures/04_tuple_operations.py` |
| 3.5 | 3.5 Phone Book | `03_Data_Structures/05_phone_book.py` |
| 3.6 | 3.6 Word Frequency Counter | `03_Data_Structures/06_word_frequency_counter.py` |
| 3.7 | 3.7 Set Operations Lab | `03_Data_Structures/07_set_operations.py` |
| 3.8 | 3.8 2D Matrix (Nested List) | `03_Data_Structures/08_2d_matrix.py` |
| 3.9 | 3.9 Student Gradebook | `03_Data_Structures/09_student_gradebook.py` |
| 3.10 | 3.10 Duplicate Remover | `03_Data_Structures/10_duplicate_remover.py` |
| 3.11 | 3.11 Inventory System | `03_Data_Structures/11_inventory_system.py` |
| 3.12 | 3.12 Combined Data Structures: To-do List | `03_Data_Structures/12_todo_list_combined_ds.py` |
