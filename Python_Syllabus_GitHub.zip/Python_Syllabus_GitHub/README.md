# Python Practical Syllabus — GitHub Repository

This repository contains **48 topic-based Python practical programs** organized according to the uploaded syllabus.

## Folder structure

- `01_Python_Basics/` — Practicals 1.1–1.24 (24 programs)
- `02_Functions_and_Strings/` — Practicals 2.1–2.12 (12 programs)
- `03_Data_Structures/` — Practicals 3.1–3.12 (12 programs)

## How to run a program

1. Install Python 3.
2. Download or clone this repository.
3. Open a terminal in the repository folder.
4. Run one file, for example:

```bash
python 01_Python_Basics/01_hello_world.py
```

On Windows, `py` may also work:

```bash
py 01_Python_Basics/01_hello_world.py
```

Each file is an independent program. Run one at a time.

## Before submitting

- In `01_hello_world.py`, replace the sample name, roll number, programme and semester with your own details.
- Check any sample student names and example values and personalize them if your teacher requires it.
- Run each file once and confirm it works before submission.
- The ATM PIN is a classroom demonstration only; do not use a real PIN.

## Upload to GitHub

1. Sign in at https://github.com and create a new repository (for example, `python-practical-syllabus`).
2. Keep the repository public if your teacher needs to view it, unless your teacher requests private.
3. Upload the three folders and this `README.md`, or use GitHub Desktop / Git commands.
4. Copy the repository URL and submit it to your teacher.

## Syllabus coverage

### Unit 1 — Python Basics
1.1 Hello World & Introduction; 1.2 Formatted Introduction; 1.3 Simple Interest; 1.4 Temperature Converter; 1.5 Area & Perimeter; 1.6 Salary Calculator; 1.7 Digit Extractor; 1.8 Unit Converter; 1.9 Swap Without Temporary Variable; 1.10 BMI Calculator; 1.11 Percentage Calculator; 1.12 Electric Bill; 1.13 Number Classifier; 1.14 Grade Calculator; 1.15 Multiplication Table; 1.16 Factorial; 1.17 Prime Checker & List; 1.18 Fibonacci Series; 1.19 Reversal & Palindrome; 1.20 Star Patterns; 1.21 Armstrong Number; 1.22 ATM PIN Simulator; 1.23 Sum of Series; 1.24 Number Pattern.

### Unit 2 — Functions and Strings
2.1 Function Basics; 2.2 Prime Checker Function; 2.3 Factorial Function; 2.4 Multiple Return Function; 2.5 String Reverse & Palindrome; 2.6 Vowel Counter & Character Frequency; 2.7 Modular Calculator; 2.8 String Methods; 2.9 Anagram Checker; 2.10 Report Card with f-strings; 2.11 Default Parameter Function; 2.12 Lambda Sort.

### Unit 3 — Data Structures
3.1 List Statistics; 3.2 Stack Simulator; 3.3 List Comprehension; 3.4 Tuple Operations; 3.5 Phone Book; 3.6 Word Frequency Counter; 3.7 Set Operations; 3.8 2D Matrix; 3.9 Student Gradebook; 3.10 Duplicate Remover; 3.11 Inventory System; 3.12 Combined Data Structures / To-do List.
