"""Practical: 1.1 Hello World & Introduction"""

print("Name: Your Full Name")
print("Roll Number: Your Roll Number")
print("Programme: B.Sc. IT")
print("Current Semester: Your Semester")
